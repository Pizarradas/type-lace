# Ganzúa Lacre v0.5.2 (nombre provisional)

Tipografía de plumilla y cincel para una empresa de salas de escape. Un solo estilo, Regular.

- 115 glifos: minúscula y versal básicas, cifras, puntuación española, comillas latinas, €, ª º, °,
  y las acentuadas del español (á é í ó ú ü ñ y versales) compuestas con marcas y anclas.
- Comprobada con la skill syx--typography: auditoría matemática sin errores, OTS limpio,
  pruebas de conformación superadas y español soportado según Hyperglot.

## Licencia

SIL Open Font License 1.1 (OFL.txt). Puedes usarla, estudiarla, modificarla y redistribuirla,
también en productos comerciales; no puedes venderla sola, y sus derivados siguen en OFL.
Sin nombre reservado.

## Estado

Versión de trabajo: el nombre es provisional y faltan el kerning, la arroba, el et y otros
signos de uso menos frecuente.

## Procedencia

Formas decididas y dibujadas por código por un agente de IA (Claude) con la skill
syx--typography, siguiendo el brief; dirección, elecciones y aprobaciones de José Luis Pizarro.
El registro por glifo las marca como «generado por IA».

Archivos: GanzuaLacre-Regular.ttf (escritorio), .otf (contornos cúbicos), .woff2 (web).

Más información: https://pizarradas.github.io/ganzua-lacre/
La skill: https://github.com/Pizarradas/syx--typography
